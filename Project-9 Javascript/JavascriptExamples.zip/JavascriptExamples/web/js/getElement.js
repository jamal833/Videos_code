/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


 function clickDiv()
            {
                var theDiv = document.getElementById("firstdiv");
                theDiv.innerHTML = "Value has been changed from JS file....";
                theDiv.style="border:2px solid blue;width:200px;height:150px;";
            }