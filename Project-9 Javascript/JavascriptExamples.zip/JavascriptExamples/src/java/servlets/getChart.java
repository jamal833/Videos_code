/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import data.Datum;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author o_molloy
 */
@WebServlet(name = "getChart", urlPatterns =
{
    "/getChart"
})
public class getChart extends HttpServlet
{

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        List<Datum> points = new ArrayList();

        Datum d1 = new Datum();
        d1.setX(0.0);
        d1.setY(2.0);
        d1.setLabel("jan");
        points.add(d1);
        
        Datum d2 = new Datum();
        d2.setX(1.0);
        d2.setY(5.0);
        d2.setLabel("feb");
        points.add(d2);
        
        Datum d3 = new Datum();
        d3.setX(2.0);
        d3.setY(3.5);
        d3.setLabel("mar");
        points.add(d3);        
        
        Datum d4 = new Datum();
        d4.setX(3.0);
        d4.setY(7.6);
        d4.setLabel("apr");
        points.add(d4);        
        
        Datum d5 = new Datum();
        d5.setX(4.0);
        d5.setY(1.4);
        d5.setLabel("may");
        points.add(d5);
        
        System.out.println(points.toString());
        
        HttpSession session = request.getSession();
        session.setAttribute("points", points);
        
        request.getRequestDispatcher("chartJS.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
